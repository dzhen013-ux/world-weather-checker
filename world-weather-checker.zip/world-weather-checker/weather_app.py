#!/usr/bin/env python3
"""
World Weather Checker
查看世界各地天气的命令行小工具。

数据来源：Open-Meteo（无需 API Key）
文档：https://open-meteo.com/

用法示例：
    python weather_app.py
    python weather_app.py --city Singapore
    python weather_app.py --city Tokyo --country Japan
    python weather_app.py --city London --country United Kingdom --days 5
"""

import argparse
import sys
from datetime import datetime
from typing import Any, Dict, List, Optional

import requests

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

WEATHER_CODES = {
    0: "晴朗",
    1: "大致晴朗",
    2: "局部多云",
    3: "阴天",
    45: "有雾",
    48: "雾凇",
    51: "小毛毛雨",
    53: "中等毛毛雨",
    55: "强毛毛雨",
    56: "轻微冻毛毛雨",
    57: "强冻毛毛雨",
    61: "小雨",
    63: "中雨",
    65: "大雨",
    66: "轻微冻雨",
    67: "强冻雨",
    71: "小雪",
    73: "中雪",
    75: "大雪",
    77: "雪粒",
    80: "小阵雨",
    81: "中等阵雨",
    82: "强阵雨",
    85: "小阵雪",
    86: "强阵雪",
    95: "雷暴",
    96: "雷暴并有小冰雹",
    99: "雷暴并有大冰雹",
}


def get_json(url: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """请求 JSON API，并提供清晰的网络错误提示。"""
    try:
        response = requests.get(url, params=params, timeout=15)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as exc:
        raise RuntimeError(f"无法连接天气服务：{exc}") from exc
    except ValueError as exc:
        raise RuntimeError("天气服务返回的数据无法解析。") from exc


def find_locations(city: str, country: Optional[str] = None) -> List[Dict[str, Any]]:
    """通过城市名搜索地点；可选国家名用于筛选结果。"""
    data = get_json(
        GEOCODING_URL,
        {"name": city, "count": 10, "language": "zh", "format": "json"},
    )
    results = data.get("results", [])
    if country:
        country_lower = country.casefold()
        filtered = [
            place for place in results
            if country_lower in str(place.get("country", "")).casefold()
            or country_lower in str(place.get("country_code", "")).casefold()
        ]
        results = filtered

    if not results:
        suffix = f"（国家：{country}）" if country else ""
        raise RuntimeError(f"没有找到地点：{city}{suffix}。请检查城市名或国家名。")
    return results


def fetch_weather(latitude: float, longitude: float, days: int) -> Dict[str, Any]:
    """获取当前天气和未来天气预报。"""
    return get_json(
        FORECAST_URL,
        {
            "latitude": latitude,
            "longitude": longitude,
            "current": (
                "temperature_2m,relative_humidity_2m,apparent_temperature,"
                "is_day,precipitation,weather_code,wind_speed_10m"
            ),
            "daily": (
                "weather_code,temperature_2m_max,temperature_2m_min,"
                "precipitation_probability_max"
            ),
            "timezone": "auto",
            "forecast_days": days,
        },
    )


def describe_location(place: Dict[str, Any]) -> str:
    parts = [
        place.get("name", "未知地点"),
        place.get("admin1"),
        place.get("country"),
    ]
    return ", ".join(str(part) for part in parts if part)


def show_weather(place: Dict[str, Any], days: int = 3) -> None:
    data = fetch_weather(place["latitude"], place["longitude"], days)
    current = data.get("current", {})
    units = data.get("current_units", {})
    daily = data.get("daily", {})
    daily_units = data.get("daily_units", {})

    code = current.get("weather_code")
    condition = WEATHER_CODES.get(code, f"未知天气代码（{code}）")
    print("\n" + "=" * 54)
    print(f"地点：{describe_location(place)}")
    print(f"坐标：{place['latitude']:.3f}, {place['longitude']:.3f}")
    print("-" * 54)
    print("当前天气")
    print(f"  时间：{current.get('time', '未知')}")
    print(f"  天气：{condition}")
    print(f"  温度：{current.get('temperature_2m', '未知')} {units.get('temperature_2m', '°C')}")
    print(f"  体感：{current.get('apparent_temperature', '未知')} {units.get('apparent_temperature', '°C')}")
    print(f"  湿度：{current.get('relative_humidity_2m', '未知')}%")
    print(f"  风速：{current.get('wind_speed_10m', '未知')} {units.get('wind_speed_10m', 'km/h')}")
    print(f"  降水量：{current.get('precipitation', '未知')} {units.get('precipitation', 'mm')}")

    dates = daily.get("time", [])
    codes = daily.get("weather_code", [])
    highs = daily.get("temperature_2m_max", [])
    lows = daily.get("temperature_2m_min", [])
    rain_chances = daily.get("precipitation_probability_max", [])

    print(f"\n未来 {len(dates)} 天预报")
    for i, date in enumerate(dates):
        daily_code = codes[i] if i < len(codes) else None
        daily_condition = WEATHER_CODES.get(daily_code, "未知")
        high = highs[i] if i < len(highs) else "?"
        low = lows[i] if i < len(lows) else "?"
        rain = rain_chances[i] if i < len(rain_chances) else "?"
        print(
            f"  {date}: {daily_condition}，"
            f"最高 {high}{daily_units.get('temperature_2m_max', '°C')}，"
            f"最低 {low}{daily_units.get('temperature_2m_min', '°C')}，"
            f"降水概率 {rain}%"
        )
    print("=" * 54)


def choose_location(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """搜索结果不唯一时，让用户选择正确的地点。"""
    if len(results) == 1:
        return results[0]

    print("\n找到多个地点，请选择：")
    for index, place in enumerate(results, start=1):
        print(f"  {index}. {describe_location(place)}")
    while True:
        answer = input("输入编号（直接回车选择第 1 个）：").strip()
        if not answer:
            return results[0]
        try:
            choice = int(answer)
            if 1 <= choice <= len(results):
                return results[choice - 1]
        except ValueError:
            pass
        print(f"请输入 1 到 {len(results)} 之间的编号。")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="查询世界各地的当前天气和未来预报（数据来自 Open-Meteo）。"
    )
    parser.add_argument("--city", help="城市名称，例如 Singapore、Tokyo、London")
    parser.add_argument("--country", help="国家名称或国家代码，例如 Japan、SG")
    parser.add_argument(
        "--days", type=int, default=3, choices=range(1, 8),
        metavar="{1,2,3,4,5,6,7}", help="预报天数，1–7 天，默认 3 天"
    )
    args = parser.parse_args()

    print("世界天气查询 World Weather Checker")
    print("数据来源：Open-Meteo | 无需 API Key")

    city = args.city or input("\n请输入城市名称（例如 Singapore、Tokyo、Paris）：").strip()
    if not city:
        print("错误：城市名称不能为空。", file=sys.stderr)
        return 2

    country = args.country
    if not country and not args.city:
        country = input("国家名称（可选，直接回车跳过）：").strip() or None

    try:
        places = find_locations(city, country)
        place = choose_location(places)
        show_weather(place, args.days)
    except (RuntimeError, KeyError) as exc:
        print(f"\n错误：{exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\n已取消。")
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
